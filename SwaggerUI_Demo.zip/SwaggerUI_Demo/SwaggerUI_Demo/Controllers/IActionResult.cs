﻿namespace SwaggerUI_Demo.Controllers
{
	public interface IActionResult<T>
	{
	}
}
