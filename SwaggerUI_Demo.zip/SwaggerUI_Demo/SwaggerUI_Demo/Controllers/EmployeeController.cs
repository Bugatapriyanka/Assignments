﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SwaggerUI_Demo.Models;
using SwaggerUI_Demo.Repositories;
using System.Collections.Generic;
using System.IO;

namespace SwaggerUI_Demo.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class EmployeeController : ControllerBase
	{
		private readonly IEmployeeRepo Repositories = null;
		public EmployeeController(IEmployeeRepo repo)
		{
			Repositories = repo;	
		}
		[HttpGet]
		public ActionResult<List<Employee>> Get()
		{
			List<Employee> employees = Repositories.GetAllEmployees();
			if(employees.Count>0)
			{
				return employees;

			}
			else
			{
				return NotFound();
			}
		}
		[Route("{id:int}")]
		[HttpGet]
		public ActionResult<Employee> Get(int id)
		{
			Employee employee = Repositories.GetEmployeeById(id);
			if (employee != null)
			{
				return employee;
			}
			else
			{
				return NotFound();
			}
		}
		[Route("{location:alpha}")]
		[HttpGet]
		public ActionResult<List<Employee>> Get(string gender)
		{
			List<Employee> employees = Repositories.GetEmployeeByGender(gender);
			if(employees.Count>0)
			{
				return employees;
			}
			else
			{
				return NotFound();
			}
		}
		[HttpPost]
		public string Post(Employee employee)
		{
			string Response = Repositories.AddnewEmployee(employee);
			return Response;
		}
		[HttpPut]
		public string Put(Employee employee)
		{
			string Response = Repositories.UpdateEmployee(employee);
			return Response;
		}
		[HttpDelete]
		public string Delete(int id)
		{
			string Response = Repositories.DeleteEmployee(id);
			return Response;
		}
	}
}
