﻿using SwaggerUI_Demo.Models;
using System.Collections.Generic;

namespace SwaggerUI_Demo.Repositories
{
	public interface IDepartmentRepo
	{
		List<Department> GetAllDepartments();
		Department GetDepartmentById(int id);
		List<Department> GetDepartmentByLocation(string Location);
		string AddnewDepartment(Department department);
		string UpdateDepartment(Department department);
		string DeleteDepartment(int deptid);
	}
}
