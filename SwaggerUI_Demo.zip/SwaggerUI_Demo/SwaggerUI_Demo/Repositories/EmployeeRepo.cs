﻿using SwaggerUI_Demo.Models;
using System.Collections.Generic;
using System.Linq;
using System;

namespace SwaggerUI_Demo.Repositories
{
	public class EmployeeRepo:IEmployeeRepo
	{
		private MyDbContext context;
		public EmployeeRepo(MyDbContext _context)
		{
			context = _context;
		}

		public string AddnewEmployee(Employee employee)
		{
			int count = context.Employees.Count();
			context.Employees.Add(employee);
			context.SaveChanges();
			int newCount = context.Employees.Count();
			if (newCount > count)
			{
				return "Record inserted successfully";
			}
			else
				return "oops something went wrong while inserting the record";
		}

		public string DeleteEmployee(int empid)
		{
			Employee emp = context.Employees.Find(empid);
			if (emp != null)
			{
				context.Employees.Remove(emp);
				context.SaveChanges();
				return "Employee removed from Database";

			}
			else
				return "Given Employee is not available";
		}

		public List<Employee> GetAllEmployees()
		{
			return context.Employees.ToList();
		}

		public List<Employee> GetEmployeeByGender(string gender)
		{
			List<Employee> employees = context.Employees.Where(d => d.Gender == gender).ToList();
			return employees;
		}

		public Employee GetEmployeeById(int id)
		{
			Employee employee = context.Employees.Find(id);
			return employee;
		}

		public string UpdateEmployee(Employee employee)
		{
			throw new System.NotImplementedException();
		}
	}
}
