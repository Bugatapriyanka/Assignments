﻿using SwaggerUI_Demo.Models;
using System.Collections.Generic;

namespace SwaggerUI_Demo.Repositories
{
	public interface IEmployeeRepo
	{
		List<Employee> GetAllEmployees();
		Employee GetEmployeeById(int id);
		List<Employee> GetEmployeeByGender(string Gender);
		string AddnewEmployee(Employee employee);
		string UpdateEmployee(Employee employee);
		string DeleteEmployee(int empid);

	}
}
